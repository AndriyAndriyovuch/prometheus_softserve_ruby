// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "jquery"
import "popper"
import "bootstrap-sprockets"
import "@rails/actiontext"
import "trix"
import "@hotwired/turbo-rails"
import "controllers";
